.lib "$CDK_DIR/models/hspice/public/publicModel/hp14tbP" PMOS
