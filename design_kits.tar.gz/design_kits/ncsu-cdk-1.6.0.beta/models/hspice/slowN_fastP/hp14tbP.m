.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/hp14tb/hsp_rtran_lib" hp14tbp
