*N8BN SPICE BSIM3 VERSION 3.1 (HSPICE Level 49) PARAMETERS
* DATE: Jan 25/99
* LOT: n8bn                  WAF: 03
* Temperature_parameters=Default
.MODEL ami06N NMOS (                                LEVEL = 11
+VERSION = 3.1            TNOM    = 27             TOX     = 1.41E-8
+XJ      = 1.5E-7         NCH     = 1.7E17         VTH0    = 0.7086
+K1      = 0.8354582      K2      = -0.088431      K3      = 41.4403818
+K3B     = -14            W0      = 6.480766E-7    NLX     = 1E-10
+DVT0W   = 0              DVT1W   = 5.3E6          DVT2W   = -0.032
+DVT0    = 3.6139113      DVT1    = 0.3795745      DVT2    = -0.1399976
+U0      = 533.6953445    UA      = 7.558023E-10   UB      = 1.181167E-18
+UC      = 2.582756E-11   VSAT    = 1.300981E5     A0      = 0.5292985
+AGS     = 0.1463715      B0      = 1.283336E-6    B1      = 1.408099E-6
+KETA    = -0.0173166     A1      = 0              A2      = 1
+RDSW    = 2.268366E3     PRWG    = -1E-3          PRWB    = 6.320549E-5
+WR      = 1              WINT    = 2.043512E-7    LINT    = 3.034496E-8
+XL      = 0              XW      = 0              DWG     = -1.446149E-8
+DWB     = 2.077539E-8    VOFF    = -0.1137226     NFACTOR = 1.2880596
+CIT     = 0              CDSC    = 1.506004E-4    CDSCD   = 0
+CDSCB   = 0              ETA0    = 3.815372E-4    ETAB    = -1.029178E-3
+DSUB    = 2.173055E-4    PCLM    = 0.6171774      PDIBLC1 = 0.185986
+PDIBLC2 = 3.473187E-3    PDIBLCB = -1E-3          DROUT   = 0.4037723
+PSCBE1  = 5.998012E9     PSCBE2  = 3.788068E-8    PVAG    = 0.012927
+DELTA   = 0.01           MOBMOD  = 1              PRT     = 0
+UTE     = -1.5           KT1     = -0.11          KT1L    = 0
+KT2     = 0.022          UA1     = 4.31E-9        UB1     = -7.61E-18
+UC1     = -5.6E-11       AT      = 3.3E4          WL      = 0
+WLN     = 1              WW      = 0              WWN     = 1
+WWL     = 0              LL      = 0              LLN     = 1
+LW      = 0              LWN     = 1              LWL     = 0
+CAPMOD  = 2              XPART   = 0.4            CGDO    = 1.99E-10
+CGSO    = 1.99E-10       CGBO    = 0              CJ      = 4.233802E-4
+PB      = 0.9899238      MJ      = 0.4495859      CJSW    = 3.825632E-10
+PBSW    = 0.1082556      MJSW    = 0.1083618      PVTH0   = 0.0212852
+PRDSW   = -16.1546703    PK2     = 0.0253069      WKETA   = 0.0188633
+LKETA   = 0.0204965       )
