.lib "$CDK_DIR/models/hspice/public/publicModel/tsmc35P" PMOS
