.lib "$CDK_DIR/models/hspice/public/publicModel/tsmc25N" NMOS
