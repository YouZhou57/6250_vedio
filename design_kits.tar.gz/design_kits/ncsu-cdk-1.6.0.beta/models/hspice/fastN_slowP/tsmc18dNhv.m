.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc18d/log018.l" FS_3V
.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc18d/log018.l" NMOS_3V
