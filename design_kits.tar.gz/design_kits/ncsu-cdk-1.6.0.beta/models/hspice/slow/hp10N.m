.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/hp10qa/hsp_slow_lib" hp10n
