.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc25/logic025.l" SF
.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc25/logic025.l" NMOS
