.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc20/log018.l" TT
.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc20/log018.l" PMOS
