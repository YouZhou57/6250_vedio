.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc35/lmm0355v.l" TT_5V
.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc35/lmm0355v.l" NMOS_5V
