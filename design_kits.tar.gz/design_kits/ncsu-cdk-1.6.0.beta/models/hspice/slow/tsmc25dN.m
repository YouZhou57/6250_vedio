.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc25d/logic025.l" SS
.lib "/afs/eos.ncsu.edu/lockers/research/ece/dk_mosis/models/hspice/tsmc25d/logic025.l" NMOS
